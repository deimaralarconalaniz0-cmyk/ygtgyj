let total = 0;
        let cantidad = 0;

        function agregarAlCarrito(nombre, precio) {
            total += precio;
            cantidad += 1;
            document.getElementById('cant-cart').innerText = cantidad;
            document.getElementById('total-cart').innerText = total;
            alert('¡' + nombre + ' agregado al carrito!');
        }

        function vaciarCarrito() {
            total = 0;
            cantidad = 0;
            document.getElementById('cant-cart').innerText = 0;
            document.getElementById('total-cart').innerText = 0;
        }

        function filtrar(categoria, botonSeleccionado) {
            let productos = document.querySelectorAll('.tarjeta-producto');
            let botones = document.querySelectorAll('.btn-filtro');

            botones.forEach(btn => btn.classList.remove('activo'));
            
            // Marca el botón seleccionado como activo
            if (botonSeleccionado) {
                botonSeleccionado.classList.add('activo');
            }

            productos.forEach(producto => {
                if (categoria === 'todos' || producto.getAttribute('data-categoria') === categoria) {
                    producto.style.display = 'flex';
                } else {
                    producto.style.display = 'none';
                }
            });
        }
