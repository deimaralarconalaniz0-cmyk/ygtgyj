# Aroma & Dulzura

## Estructura del proyecto

- `index.html`: estructura y contenido de la página.
- `css/estilos.css`: diseño y estilos.
- `js/script.js`: funciones del carrito y filtros.
- `imagenes/`: coloca aquí las imágenes usadas por la página.

## Importante: imágenes

El HTML original usa estos nombres de archivo para las imágenes:
- `logo nuevo xd.jpg`
- `vela aromatica 14.jpg`
- `vela aromatica 11.jpg`
- `vela aromatica 10.jpg`
- `vela aromatica 15.jpg`
- `vela aromatica 18 .jpg`
- `vela aomatica 16.jpg`
- `vela aromatica 19.jpg`
- `vela de mandarina.jpg`
- `vela aromatica 13.jpg`

Para que se vean en GitHub Pages, copia las imágenes a la carpeta `imagenes/` y cambia las rutas del HTML a `imagenes/nombre-del-archivo.jpg`, o deja las imágenes en la raíz del repositorio con los nombres exactos que ya aparecen en el HTML. GitHub distingue mayúsculas, minúsculas y espacios en los nombres.

## Publicar con GitHub Pages

1. Sube `index.html`, `css/`, `js/` y las imágenes al repositorio.
2. En GitHub, abre **Settings → Pages**.
3. En **Build and deployment**, elige **Deploy from a branch**.
4. Selecciona la rama `main` (o la rama que uses) y la carpeta `/ (root)`.
5. Pulsa **Save** y espera a que aparezca el enlace de GitHub Pages.
